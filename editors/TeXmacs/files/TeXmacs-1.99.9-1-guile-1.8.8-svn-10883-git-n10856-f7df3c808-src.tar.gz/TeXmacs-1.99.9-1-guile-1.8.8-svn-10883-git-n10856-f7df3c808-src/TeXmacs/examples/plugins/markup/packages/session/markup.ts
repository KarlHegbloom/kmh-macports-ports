<TeXmacs|1.0.1.20>

<\body>
  <assign|markup-output|<macro|body|<expand|generic-output|<with|paragraph
  mode|center|<arg|body>>>>>

  \;

  <with|mode|math|<assign|foo|<func|x|<frac|1|1+<apply|x>>>>>

  \;
</body>

<\initial>
  <\collection>
    <associate|preamble|true>
    <associate|odd page margin|30mm>
    <associate|paragraph width|150mm>
    <associate|shrinking factor|4>
    <associate|page right margin|30mm>
    <associate|page top margin|30mm>
    <associate|reduction page right margin|25mm>
    <associate|reduction page bottom margin|15mm>
    <associate|page type|a4>
    <associate|reduction page left margin|25mm>
    <associate|even page margin|30mm>
    <associate|page bottom margin|30mm>
    <associate|reduction page top margin|15mm>
  </collection>
</initial>
